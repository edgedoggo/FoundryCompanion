const MODULE_ID = "foundry-companion";
const MIN_PERMISSION = "LIMITED";

const QUEST_STATUS_LABELS = {
  active: "Active",
  available: "Available",
  completed: "Completed",
  failed: "Failed",
  inactive: "Inactive",
  hidden: "Hidden"
};

const openApps = new Set();

Hooks.once("init", () => {
  game.settings.registerMenu(MODULE_ID, "companion", {
    name: "FoundryCompanion",
    label: "Open",
    hint: "Open the live player-facing companion page or export it as HTML.",
    icon: "fas fa-book-open",
    type: FoundryCompanionMenu,
    restricted: false
  });

  game.settings.register(MODULE_ID, "worldTitle", {
    name: "Companion title",
    hint: "Shown at the top of the live page and exported HTML.",
    scope: "world",
    config: true,
    type: String,
    default: game.world?.title ?? "FoundryCompanion"
  });

  game.settings.register(MODULE_ID, "refreshSeconds", {
    name: "Live refresh seconds",
    hint: "How often the live companion page refreshes itself while open.",
    scope: "client",
    config: true,
    type: Number,
    default: 10,
    range: {
      min: 3,
      max: 60,
      step: 1
    }
  });
});

Hooks.once("ready", () => {
  game.foundryCompanion = {
    open: () => new FoundryCompanionApp().render(true),
    exportHtml: () => FoundryCompanion.download(),
    debug: () => FoundryCompanion.copyDebugSample()
  };

  const refresh = () => FoundryCompanion.refreshOpenApps();
  [
    "createJournalEntry",
    "updateJournalEntry",
    "deleteJournalEntry",
    "createJournalEntryPage",
    "updateJournalEntryPage",
    "deleteJournalEntryPage",
    "updateSetting"
  ].forEach((hook) => Hooks.on(hook, refresh));

  Hooks.on("renderForienQuestLog", refresh);
  Hooks.on("closeForienQuestLog", refresh);

  console.info(`${MODULE_ID} | Ready. Use Configure Settings > Module Settings > FoundryCompanion.`);
});

class FoundryCompanionMenu extends FormApplication {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "foundry-companion-menu",
      title: "FoundryCompanion",
      template: `modules/${MODULE_ID}/templates/export-menu.hbs`,
      width: 520,
      closeOnSubmit: false
    });
  }

  getData() {
    const quests = FoundryCompanion.collectVisibleQuests(game.user);
    return {
      count: quests.length,
      username: game.user.name,
      title: game.settings.get(MODULE_ID, "worldTitle")
    };
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find("[data-action='open']").on("click", () => {
      new FoundryCompanionApp().render(true);
      this.close();
    });
    html.find("[data-action='export']").on("click", async () => {
      await FoundryCompanion.download();
    });
    html.find("[data-action='debug']").on("click", async () => {
      await FoundryCompanion.copyDebugSample();
    });
  }
}

class FoundryCompanionApp extends Application {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "foundry-companion-app",
      title: "FoundryCompanion",
      template: `modules/${MODULE_ID}/templates/companion-page.hbs`,
      width: 900,
      height: "auto",
      resizable: true,
      classes: ["foundry-companion-window"]
    });
  }

  getData() {
    const quests = FoundryCompanion.collectVisibleQuests(game.user);
    return {
      title: game.settings.get(MODULE_ID, "worldTitle") || "FoundryCompanion",
      worldTitle: game.world.title,
      username: game.user.name,
      updatedAt: new Date().toLocaleTimeString(),
      count: quests.length,
      sections: FoundryCompanion.groupForTemplate(quests)
    };
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find("[data-action='refresh']").on("click", () => this.render(false));
    html.find("[data-action='export']").on("click", () => FoundryCompanion.download());
  }

  async _render(force, options) {
    await super._render(force, options);
    openApps.add(this);
    this.startLiveRefresh();
  }

  close(options) {
    window.clearInterval(this.refreshTimer);
    openApps.delete(this);
    return super.close(options);
  }

  startLiveRefresh() {
    window.clearInterval(this.refreshTimer);
    const seconds = Math.max(3, Number(game.settings.get(MODULE_ID, "refreshSeconds") || 10));
    this.refreshTimer = window.setInterval(() => this.render(false), seconds * 1000);
  }
}

class FoundryCompanion {
  static refreshOpenApps() {
    for (const app of openApps) app.render(false);
  }

  static collectVisibleQuests(user) {
    return this.collectQuestSources()
      .flatMap((source) => this.normalizeSource(source))
      .filter((quest) => this.canUserSeeQuest(quest.raw, user))
      .map((quest) => this.normalizeQuest(quest.raw, quest.source))
      .filter((quest) => quest.title);
  }

  static collectQuestSources() {
    const sources = [];
    const push = (name, value) => {
      if (value) sources.push({ name, value });
    };

    push("Forien's Quest Log", game.quests);
    push("Forien's Quest Log", game.fql?.quests);
    push("Forien's Quest Log", game.fql?.QuestDatabase);
    push("Forien's Quest Log", globalThis.ForienQuestLog?.quests);
    push("Forien's Quest Log", globalThis.ForienQuestLog?.QuestDatabase);
    push("Forien's Quest Log", globalThis.ForienQuestLog?.database);
    push("Forien's Quest Log", game.modules.get("forien-quest-log")?.api?.quests);
    push("Forien's Quest Log", game.modules.get("forien-quest-log")?.api?.QuestDatabase);

    const questJournals = game.journal?.filter((entry) => {
      const flagBuckets = [
        entry.flags?.["forien-quest-log"],
        entry.flags?.forienQuestLog,
        entry.flags?.quests
      ];
      return flagBuckets.some(Boolean) || /\bquest|mission|rumor|job\b/i.test(entry.name);
    }) ?? [];
    push("Journal", questJournals);

    return this.dedupeSources(sources);
  }

  static dedupeSources(sources) {
    const seenObjects = new WeakSet();
    const seenPrimitives = new Set();
    return sources.filter((source) => {
      if (source.value && typeof source.value === "object") {
        if (seenObjects.has(source.value)) return false;
        seenObjects.add(source.value);
        return true;
      }

      const key = `${source.name}:${source.value}`;
      if (seenPrimitives.has(key)) return false;
      seenPrimitives.add(key);
      return true;
    });
  }

  static normalizeSource(source) {
    const value = source.value;
    const FoundryCollection = foundry.utils.Collection ?? globalThis.Collection;
    const entries = FoundryCollection && value instanceof FoundryCollection ? Array.from(value.values()) :
      value instanceof Map ? Array.from(value.values()) :
      Array.isArray(value) ? value :
      Array.isArray(value?.contents) ? value.contents :
      Array.isArray(value?.entries) ? value.entries :
      typeof value?.values === "function" ? Array.from(value.values()) :
      typeof value?.toObject === "function" ? [value] :
      Object.values(value ?? {});

    return entries
      .filter((raw) => raw && typeof raw === "object")
      .map((raw) => ({ raw, source: source.name }));
  }

  static canUserSeeQuest(quest, user) {
    if (!quest) return false;
    if (quest.visible === false || quest.hidden === true) return false;

    if (typeof quest.testUserPermission === "function") {
      return quest.testUserPermission(user, MIN_PERMISSION);
    }

    const document = quest.document ?? quest.parent ?? quest.journalEntry ?? quest.entry;
    if (typeof document?.testUserPermission === "function") {
      return document.testUserPermission(user, MIN_PERMISSION);
    }

    const ownership = quest.ownership ?? quest.permission ?? quest.data?.ownership ?? quest.data?.permission;
    if (!ownership) return game.user?.isGM === true;

    const levels = CONST.DOCUMENT_OWNERSHIP_LEVELS ?? CONST.DOCUMENT_PERMISSION_LEVELS;
    const none = levels?.NONE ?? 0;
    const limited = levels?.LIMITED ?? 1;
    const userLevel = ownership[user.id] ?? ownership[user.role] ?? ownership.default ?? none;
    return userLevel >= limited;
  }

  static normalizeQuest(raw, source) {
    const data = raw.toObject?.() ?? raw;
    const system = raw.system ?? data.system ?? raw.data?.data ?? data.data?.data ?? {};
    const flags = raw.flags ?? data.flags ?? {};
    const fql = flags["forien-quest-log"] ?? flags.forienQuestLog ?? flags.quests ?? {};
    const status = this.firstValue(raw.status, data.status, system.status, fql.status, raw.state, data.state, system.state);
    const title = this.firstValue(raw.name, data.name, raw.title, data.title, system.name, fql.name, "Untitled Quest");

    return {
      id: raw.id ?? data._id ?? data.id ?? foundry.utils.randomID(),
      title,
      status: QUEST_STATUS_LABELS[status] ?? status ?? "Quest",
      source,
      description: this.cleanHtml(this.firstValue(
        raw.description,
        data.description,
        raw.content,
        data.content,
        system.description,
        system.content,
        fql.description,
        fql.content,
        this.journalText(raw)
      )),
      objectives: this.normalizeList(this.firstValue(raw.objectives, data.objectives, system.objectives, fql.objectives, raw.tasks, data.tasks, system.tasks)),
      rewards: this.normalizeList(this.firstValue(raw.rewards, data.rewards, system.rewards, fql.rewards)),
      location: this.firstValue(raw.location, data.location, system.location, fql.location, ""),
      giver: this.firstValue(raw.giver, data.giver, raw.questGiver, data.questGiver, system.giver, fql.giver, "")
    };
  }

  static journalText(raw) {
    const pages = raw.pages?.contents ?? raw.pages ?? [];
    return Array.from(pages)
      .filter((page) => page.type === "text" || page.text?.content)
      .map((page) => page.text?.content ?? page.data?.text?.content ?? "")
      .join("\n");
  }

  static normalizeList(value) {
    if (!value) return [];
    const list = Array.isArray(value) ? value : Object.values(value);
    return list.map((item) => {
      if (typeof item === "string") return { label: item, done: false };
      return {
        label: this.firstValue(item.name, item.title, item.label, item.description, item.content, ""),
        done: Boolean(item.done ?? item.completed ?? item.checked)
      };
    }).filter((item) => item.label);
  }

  static firstValue(...values) {
    return values.find((value) => value !== undefined && value !== null && value !== "");
  }

  static cleanHtml(value) {
    if (!value) return "";
    const div = document.createElement("div");
    div.innerHTML = String(value);
    div.querySelectorAll("script, iframe, object, embed").forEach((node) => node.remove());
    div.querySelectorAll("*").forEach((node) => {
      [...node.attributes].forEach((attr) => {
        if (/^on/i.test(attr.name)) node.removeAttribute(attr.name);
      });
    });
    return div.innerHTML.trim();
  }

  static groupForTemplate(quests) {
    return Object.entries(this.groupByStatus(quests)).map(([status, items]) => ({ status, items }));
  }

  static groupByStatus(quests) {
    return quests.reduce((groups, quest) => {
      const status = quest.status || "Quest";
      groups[status] ??= [];
      groups[status].push(quest);
      return groups;
    }, {});
  }

  static async download() {
    const quests = this.collectVisibleQuests(game.user);
    const title = game.settings.get(MODULE_ID, "worldTitle") || "FoundryCompanion";
    const html = this.renderHtml({ title, quests, exportedAt: new Date(), user: game.user });
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${toSlug(title)}-quests.html`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  static async copyDebugSample() {
    const sources = this.collectQuestSources().map((source) => {
      const normalized = this.normalizeSource(source);
      return {
        source: source.name,
        count: normalized.length,
        samples: normalized.slice(0, 3).map(({ raw }) => this.summarizeRawQuest(raw))
      };
    });

    const payload = {
      foundry: game.version,
      system: game.system?.id,
      systemVersion: game.system?.version,
      forienQuestLogVersion: game.modules.get("forien-quest-log")?.version,
      likelyQuestGlobals: this.findLikelyQuestGlobals(),
      forienSettings: this.findForienSettings(),
      user: {
        id: game.user.id,
        name: game.user.name,
        role: game.user.role,
        isGM: game.user.isGM
      },
      sources
    };

    const text = JSON.stringify(payload, null, 2);
    await navigator.clipboard.writeText(text);
    ui.notifications.info("FoundryCompanion debug sample copied to clipboard.");
    console.log(`${MODULE_ID} debug sample`, payload);
  }

  static summarizeRawQuest(raw) {
    if (!raw) return null;
    const data = raw.toObject?.() ?? raw;
    return {
      constructor: raw.constructor?.name,
      id: raw.id ?? raw._id ?? data.id ?? data._id,
      name: raw.name ?? raw.title ?? data.name ?? data.title,
      keys: Object.keys(data).slice(0, 50),
      ownership: data.ownership ?? data.permission ?? raw.ownership ?? raw.permission,
      flags: data.flags,
      system: data.system,
      data: data.data
    };
  }

  static findLikelyQuestGlobals() {
    return Object.keys(globalThis)
      .filter((key) => /quest|forien|fql/i.test(key))
      .sort()
      .slice(0, 80);
  }

  static findForienSettings() {
    const storage = game.settings.storage?.get("world") ?? [];
    return Array.from(storage)
      .map((setting) => setting.key ?? setting.id ?? "")
      .filter((key) => /forien|quest|fql/i.test(key))
      .sort();
  }

  static renderHtml({ title, quests, exportedAt, user }) {
    const grouped = this.groupByStatus(quests);
    const sections = Object.entries(grouped).map(([status, items]) => this.renderSection(status, items)).join("");

    return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>${this.exportCss()}</style>
</head>
<body>
  <header class="site-header">
    <p class="eyebrow">${escapeHtml(game.world.title)}</p>
    <h1>${escapeHtml(title)}</h1>
    <p class="meta">Exported for ${escapeHtml(user.name)} on ${escapeHtml(exportedAt.toLocaleString())}</p>
  </header>
  <main>
    ${sections || "<p class=\"empty\">No visible quests were found for this user.</p>"}
  </main>
</body>
</html>`;
  }

  static renderSection(status, quests) {
    const questCards = quests.map((quest) => this.renderQuest(quest)).join("");
    return `<section class="quest-section">
      <h2>${escapeHtml(status)}</h2>
      <div class="quest-list">${questCards}</div>
    </section>`;
  }

  static renderQuest(quest) {
    const details = [
      quest.giver ? `<span>Giver: ${escapeHtml(quest.giver)}</span>` : "",
      quest.location ? `<span>Location: ${escapeHtml(quest.location)}</span>` : "",
      quest.source ? `<span>${escapeHtml(quest.source)}</span>` : ""
    ].filter(Boolean).join("");

    return `<article class="quest-card">
      <header>
        <h3>${escapeHtml(quest.title)}</h3>
        ${details ? `<p class="quest-details">${details}</p>` : ""}
      </header>
      ${quest.description ? `<div class="quest-description">${quest.description}</div>` : ""}
      ${this.renderList("Objectives", quest.objectives)}
      ${this.renderList("Rewards", quest.rewards)}
    </article>`;
  }

  static renderList(title, items) {
    if (!items?.length) return "";
    const rows = items.map((item) => `<li class="${item.done ? "is-done" : ""}">${escapeHtml(item.label)}</li>`).join("");
    return `<div class="quest-sublist"><h4>${escapeHtml(title)}</h4><ul>${rows}</ul></div>`;
  }

  static exportCss() {
    return document.querySelector("style[data-foundry-companion-export]")?.textContent ?? `
      :root { color-scheme: light; --ink: #191716; --muted: #675f59; --line: #ded6cc; --paper: #fffaf2; --panel: #ffffff; --accent: #28666e; --warm: #a65f2b; }
      * { box-sizing: border-box; }
      body { margin: 0; font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: var(--ink); background: var(--paper); line-height: 1.55; }
      .site-header { padding: 28px 18px 20px; background: #f0e7d8; border-bottom: 1px solid var(--line); }
      .site-header h1 { margin: 0; font-size: clamp(2rem, 8vw, 4.5rem); line-height: 0.95; letter-spacing: 0; }
      .eyebrow, .meta { margin: 0 0 10px; color: var(--muted); font-size: 0.9rem; }
      main { width: min(100%, 980px); margin: 0 auto; padding: 18px; }
      .quest-section { margin: 0 0 28px; }
      .quest-section h2 { margin: 0 0 12px; color: var(--accent); font-size: 1.15rem; text-transform: uppercase; letter-spacing: 0.08em; }
      .quest-list { display: grid; gap: 12px; }
      .quest-card { background: var(--panel); border: 1px solid var(--line); border-radius: 8px; padding: 16px; box-shadow: 0 1px 0 rgba(25, 23, 22, 0.04); }
      .quest-card h3 { margin: 0; font-size: 1.3rem; line-height: 1.2; letter-spacing: 0; }
      .quest-details { display: flex; flex-wrap: wrap; gap: 8px 12px; margin: 8px 0 0; color: var(--muted); font-size: 0.88rem; }
      .quest-description { margin-top: 14px; }
      .quest-description :first-child { margin-top: 0; }
      .quest-description :last-child { margin-bottom: 0; }
      .quest-sublist { margin-top: 14px; }
      .quest-sublist h4 { margin: 0 0 6px; font-size: 0.95rem; color: var(--warm); }
      ul { margin: 0; padding-left: 1.2rem; }
      li { margin: 4px 0; }
      li.is-done { color: var(--muted); text-decoration: line-through; }
      .empty { color: var(--muted); }
      @media (min-width: 760px) {
        .site-header { padding: 42px max(24px, calc((100vw - 980px) / 2)) 28px; }
        main { padding-block: 24px; }
        .quest-list { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      }
    `;
  }
}

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = String(value ?? "");
  return div.innerHTML;
}

function toSlug(value) {
  return String(value ?? "foundry-companion")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "foundry-companion";
}
